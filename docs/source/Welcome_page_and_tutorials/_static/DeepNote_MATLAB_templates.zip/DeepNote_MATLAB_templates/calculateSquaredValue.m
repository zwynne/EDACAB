function ave = calculateSquaredValue(x)
    ave = x.^2; 
end